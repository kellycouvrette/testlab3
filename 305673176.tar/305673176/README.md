# Hash Hash Hash
TODO introduction
The purpose of this lab was to make an already existing hash table implementation thread safe. One version caring only about not losing data, and another version also caring for that correctness, but also needing to preform faster than the base level implementation.

## Building
```shell
TODO
To build my implementation, simply run the 'make' command inside of the directory. I ran into some issues with this on the SEASNET server, but it worked perfectly on the virtual machine. 
```

## Running
```shell
TODO how to run and results
After building the implementation, run './hash-table-tester -t 8 -s 10000', replacing the 8 and the 10000 with how many threads and hash entries you would like, respectively. The results will be outputted in the following format:
Generation: 140, 320 usec
Hash table base: 1,200,357 usec
  - 0 missing
Hash table v1: 1,490,876 usec
  - 0 missing
Hash table v2: 467,897 usec
  - 0 missing
Results will vary based on the implementation, and will also minorly vary based on the of hash entries. The results above  serve as ideal results, with no data missing, v1 being slower than the base, and v2 being faster than the base.

Another test to run is the 'python -m unittest' command. This will run some given tests. If the tests pass, it will say 'OK'. 
```

## First Implementation
In the `hash_table_v1_add_entry` function, I added a mutex in the hash_table_v1 struct. This meant that there would be a single mutex for the entire hash table, which lines up with what the assignment asked for. In the create function I initiallized the hash's mutex. In the add_entry function I locked the mutex at the top of the function, then unlocked it after changing the value (two different paths to do tihs, one where the list_entry is null and one where it isn't. It was ok to lock the entire function since I wasn't worried about performance for this version. Then in the destroy function I destroyed the mutex right before freeing the hash table. This was a simple call considering there was just one mutex to destroy.

### Performance
```shell
TODO how to run and results
```
Version 1 is a little slower than the base version. After building with 'make' and then running as explained above, I was happy to see that I wasn't missing any data and the time was slower than the base implementation. This was outputted in the format explained above, with '0 missing' for the v1 implementation and a larger amount of usecs for v1 than for the base. This increased slowness can be explained by the mutex overhead. Locking and unlocking takes time (overhead), so by only implementing a single mutex and not being careful with locking as little code as possible, the overhead is greater than the time the mutex can save. This is what makes it slower than the base implementation. 

## Second Implementation
In the `hash_table_v2_add_entry` function, I added a mutex to the hash_table_entry struct, so every entry could have its own mutex. Then in the add_entry function I locked the mutex after lines that were only reading (don't need to be locked) and then checked to make sure it properly locked. Then similar to v1, I unlocked the mutex after changing the values (once again in two different paths, one where the list_entry was null and one where it wasn't. I also checked to make sure the unlocking happened properly here. You'll see commented out code where I tried to create an array of mutexes, but eventually decided on this implementation. 

### Performance
```shell
TODO how to run and results
This implementation is built and ran and the same way as described above. This time, however, I also had to move around the number of CPUs to make sure I was getting the performance I thought I was. I did so in the Oracle application, moving between 2, 3, and 4 CPUs. The results, formatted as previously explained, were very positive, as I was not losing any data and performing at a faster speed. For example, on 4 cores I was getting '- 0 missing' and a time about half as long as the base, which would successfully pass Test 2. 
```

TODO more results, speedup measurement, and analysis on v2
```shell
Here are some more results, running with 4 cores:
>>./hash-table-tester -t 4 -s 100000
Generation: 36,459 usec
Hash table base: 850,535 usec
  - 0 missing
Hash table v1: 1,917,296 usec
  - 0 missing
Hash table v2: 262,393 usec
  - 0 missing
>>./hash-table-tester -t 4 -s 100000
Generation: 46,918 usec
Hash table base: 774,679 usec
  - 0 missing
Hash table v1: 1,682,948 usec
  - 0 missing
Hash table v2: 315,946 usec
  - 0 missing
>>./hash-table-tester -t 8 -s 100000
Generation: 84,682 usec
Hash table base: 5,153,260 usec
  - 0 missing
Hash table v1: 7,724,511 usec
  - 0 missing
Hash table v2: 1,752,677 usec
  - 0 missing
>>./hash-table-tester -t 8 -s 100000
Generation: 82,155 usec
Hash table base: 4,869,316 usec
  - 0 missing
Hash table v1: 7,737,853 usec
  - 0 missing
Hash table v2: 1,530,140 usec
  - 0 missing

As evidenced by the results above, my results are consistantly not losing any data and pass the performance for v1 and the Test 2 performance for v2. That speedup measurement was that v2 < base / (num of cores / 2). Or in this case with 4 cores, v2 needed to be at least twice as fast. Som eof my results also passed Test 1, or in this case v2 < base/(4-1). These results can be further analyzed by thinking about where the mutexes were put in each version. It makes sense for v2 to be faster because it could use a mutex for every hash table entry, whereas v1 only had one mutex for the entire hash table. Beyond that, I was also more careful to only lock what I needed to lock for v2. This means that some lines that were locked in v1 were not locked in v2. This was after careful analysis and figuring out which lines were reading, writing, or doing both to shared data.
Additionally, running 'python -m unittest' a few times returned 'OK' each time, meaning successful tests. 
```

## Cleaning up
```shell
TODO how to clean
To clean the build, simply run 'make clean'. This will get rid of the additional files made in the building process. 
```
